package com.client;

import com.learners.hibernate.DAO.UsersDAO;
import com.learners.hibernate.entity.Users;

public class addUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Users admin=new Users("Administrator", "admin@gmail.com", "admin");
		
		UsersDAO usrdao=new UsersDAO();
		
		int userid=usrdao.AddUser(admin);
		System.out.println("a user admin added "+userid);
	}

}
